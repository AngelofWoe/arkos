.. cmake-module:: ../../Modules/FindCURL.cmake
